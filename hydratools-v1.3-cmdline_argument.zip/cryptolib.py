#!/usr/bin/python

# -*- coding: utf-8 -*-

import hashlib, base64
import time
from colored import fg, attr

#Define colors
green = fg(82)
red = fg(9) # can be 196
blue = fg(75)
yellow = fg(226)
reset = attr(0)


# Calculate time function
def currentTime():
        return time.ctime().split()[3] 


# Hash algorithms function
def hashlist():
        print('''
   1. MD4
   2. MD5
   3. MD5 Reverse
   4. SHA-1
   5. SHA-224
   6. SHA-256
   7. SHA-384
   8. SHA-512
   9. ripemd160
   10. whirlpool
   11. Base64
   99. All algorithms\n''')

def hashpasswd(passwd, alg):
        
        # encode input
        passwd = passwd.strip()
        passwd = passwd.encode("ascii")
        
        if alg == "md4":
                md4 = hashlib.new("md4")
                md4.update(passwd)
                result = md4.hexdigest()
                return result
        
        elif alg == "md5":
                result = hashlib.md5(passwd).hexdigest()
                return result

        elif alg == "md5reverse":
                result = hashlib.md5(passwd).hexdigest()
                result = result[::-1]
                return result
        
        elif alg == "sha-1":
                result = hashlib.sha1(passwd).hexdigest()
                return result
        
        elif alg == "sha-224":
                result = hashlib.sha224(passwd).hexdigest()
                return result
        
        elif alg == "sha-256":
                result = hashlib.sha256(passwd).hexdigest()     
                return result

        elif alg == "sha-384":
                result = hashlib.sha384(passwd).hexdigest()
                return result

        elif alg == "sha-512":
                result = hashlib.sha512(passwd).hexdigest()
                return result

        elif alg == "ripemd160":
                ripemd160 = hashlib.new("ripemd160")
                ripemd160.update(passwd)
                result = ripemd160.hexdigest()
                return result

        elif alg == "whirlpool":
                whirlpool = hashlib.new("whirlpool")
                whirlpool.update(passwd)
                result = whirlpool.hexdigest()
                return result

        elif alg == "base64":
                result = base64.b64encode(passwd)
                result = result.decode("utf8")
                return result


# Crack hash function

def crackhash(hash, algid, wordlist):
        lines = 0
        if hashTypeVerifier(hash, algorithm(algid)):    # if it's True
                try:
                        passwdlist = open(wordlist, 'r')
                except OSError:
                        print("{}[-]{} Could not open file!".format(red, reset))
                        print("{}[*]{} Exiting...".format(blue, reset))
                        quit(1)
                with open(wordlist, 'r') as file:
                        for line in file:
                                wordlst = line.split()
                                lines += 1
                        print("{}[+]{} Loaded passwords: {}".format(green, reset, lines))
                        start = time.time()     # Get start time
                        print("{}[+]{} Cracking process started at [{}]\n".format(green, reset, currentTime()))
                        for password in passwdlist:
                                try:
                                        passwd = password
                                        passwd = hashpasswd(passwd, algorithm(algid))
                                        password = password.replace('\n', '')
                                        print("{}[*]{} Trying password... :".format(blue, reset), password, "\r", end="")
                                        if hash == passwd:
                                                stop = time.time() - start
                                                elapsedTime = time.strftime("%H:%M:%S", time.gmtime(stop))      # Calculate elapsed time
                                                print("\n\n{}[+]{} Password cracked successfully at [{}]\n{}[*]{} Elapsed time: {}\n".format(green, reset, currentTime(), blue, reset, elapsedTime))
                                                print("{}[+]{} Password: {}\n\n".format(green, reset, password))
                                                break
                                except KeyboardInterrupt:
                                        print("\n\n{}[-]{} Operation canceled\n".format(red, reset))
                                        quit(1)

                        else:
                                print("\n\n{}[-]{} Password not found!\n\n".format(red, reset))
        else:
                print("{}[-]{} Invalid hash!\n\n".format(red, reset))



# Algorithm function

def algorithm(id):
    if id == 1:
        return "md4"

    elif id == 2:
        return "md5"

    elif id == 3:
        return "md5reverse"

    elif id == 4:
        return "sha-1"

    elif id == 5:
        return "sha-224"

    elif id == 6:
        return "sha-256"

    elif id == 7:
        return "sha-384"

    elif id == 8:
        return "sha-512"

    elif id == 9:
        return "ripemd160"

    elif id == 10:
        return "whirlpool"

    elif id == 11:
        return "base64"

    elif id == 99:
        return "all"



# HashIdentifier function

def hashidentifier(hash):
        if len(hash) == 32:
                return "MD5 / MD5 Reverse / MD4"
        elif len(hash) == 40:
                return "SHA-1 / MySQL5 / Ripemd160"
        elif len(hash) == 13:
                return "DES(Unix)"
        elif len(hash) == 16:
                return "MySQL / DES(Oracle Hash)"
        elif len(hash) == 41 & hash.startswith('*'):
                return "MySQL5"
        elif len(hash) == 64:
                return "SHA-256"
        elif len(hash) == 56:
                return "SHA-224"
        elif len(hash) == 96:
                return "SHA-384 / SHA-384(HMAC)"
        elif len(hash) == 128:
                return "SHA-512 / Whirlpool"
        elif len(hash) == 34 & hash.startswith('$1$'):
                return "MD5(Unix)"
        elif len(hash) == 37 & hash.startswith('$apr1$'):
                return "MD5(APR)"
        elif len(hash) == 34 & hash.startswith('$H$'):
                return "MD5(phpBB3)"
        elif len(hash) == 34 & hash.startswith('$P$'):
                return "MD5(Wordpress)"
        elif len(hash) == 39 & hash.startswith('$5$'):
                return "SHA-256(Unix)"
        elif len(hash) == 39 & hash.startswith('$6$'):
                return "SHA-512(Unix)"
        elif len(hash) == 24 & hash.endswith('=='):
                return "MD5(Base-64)"
        elif len(hash) == 28 & hash.endswith('='):
                return "SHA-1(Base-64)"
        elif len(hash) == 40 & hash.endswith('=='):
                return "SHA-224(Base-64)"
        elif len(hash) == 88 & hash.endswith('=='):
                return "SHA-512(Base-64)"
        elif len(hash) == 44 & hash.endswith('='):
                return "SHA-256(Base-64)"
        else:
                return 1



# hashTypeVerifier function

def hashTypeVerifier(hash, alg):
        if alg == "md4" or alg == "md5" or alg == "md5reverse":
                if len(hash) == 32:
                        return True

        elif alg == "sha-1" or alg == "ripemd160":
                if len(hash) == 40:
                        return True

        elif alg == "sha-224":
                if len(hash) == 56:
                        return True

        elif alg == "sha-256":
                if len(hash) == 64:
                        return True

        elif alg == "sha-384":
                if len(hash) == 96:
                        return True

        elif alg == "sha-512" or alg == "whirlpool":
                if len(hash) == 128:
                        return True

        else:
                return False



