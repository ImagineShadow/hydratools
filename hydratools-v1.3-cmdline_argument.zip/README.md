# Hydratools
**Written in python 3** 

A useful script for Encryption & Decryption.
for Reporting bugs contact me on:

**Gmail:** UnknownBlackHat.zeroday@gmail.com

**Telegram:** @UnknownBlackHat
