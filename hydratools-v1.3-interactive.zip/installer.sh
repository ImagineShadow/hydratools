#!/bin/bash

echo -e "
 ___           _        _ _ _                   
|_ _|____  ___| |_ ____| | (_)____   ____       
 | ||  _ \/ __| __/ _  | | | |  _ \ / _  |      
 | || | | \__ \ || (_| | | | | | | | (_| |_ _ _ 
|___|_| |_|___/\__\__,_|_|_|_|_| |_|\__, (_|_|_)
                                    |___/       

"

# Check if run as root
if [ `id -u` != 0 ]; then
       echo -e "\n[!] Run installer as root"
       exit 1
fi

echo -e "[!] You should setting permission of hydratools file"
echo -e "[*] Checking 'colored' python library..."
python3 -c "import colored" &> /dev/null
if [ $? -eq 0 ];then
	echo -e "[✔] 'colored' already installed"
else
	ping 8.8.8.8 -c 5 &> /dev/null
	if [ $? -eq 0 ];then
		echo -e "[*] Updating repositories..."
		apt update -y > /dev/null 2>> /var/log/hydratools.log
		if [ $? -eq 0 ];then
			echo -e "[✔] Repositories updated successfully!"
		else
			echo -e "[-] Can not update repositories\n[-] No internet connection!"
			echo -e "[*] You can check logs in /var/log/hydratools.log for more details"
			exit 1
		fi
		echo -e "[*] Installing 'colored' python library..."
		pip3 install colored > /dev/null 2>> /var/log/hydratools.log
		if [ $? -eq 0 ];then
			echo -e "[✔] colored library installed"
		else
			echo -e "[-] Can not install library\n[*] Check logs in /var/log/hydratools.log"
			echo -e "[*] Exiting..."
			exit 1
		fi
	fi
fi

echo -e "\n[*] Checking Hydratools..."
ls /usr/bin/hydratools &> /dev/null
if [ $? -eq 0 ];then
	echo -e "[✔] Hydratools already added to PATH"
else
	echo -e "[*] Adding Hydratools to PATH..."
	cp -p hydratools /usr/bin 2>> /var/log/hydratools.log
	if [ $? -eq 0 ];then
		echo -e "[✔] Hydratools added to PATH"
	else
		echo -e "[-] Can not add Hydratools to PATH\n[*] Check logs in /var/log/hydratools.log"
	        exit 1
	fi
fi

echo -e "\n[*] Checkig cryptolib..."
ls /usr/local/lib/python3.*/dist-packages/cryptolib.py &> /dev/null
if [ $? -eq 0 ];then
	echo -e "[✔] Cryptolib already added to libraries"
	echo -e "\n\n[✔] Installation completed successfully!"
	exit 0
else
	echo -e "[*] Adding cryptolib to libraries..."
	cp -p cryptolib.py /usr/local/lib/python3.6/dist-packages/ > /dev/null 2>> /var/log/hydratools.log
	cp -p cryptolib.py /usr/local/lib/python3.7/dist-packages/ > /dev/null 2>> /var/log/hydratools.log
	echo -e "[✔] Cryptolib added to libraries"
	echo -e "\n\n[✔] Installation completed successfully!"
	exit 0
fi
